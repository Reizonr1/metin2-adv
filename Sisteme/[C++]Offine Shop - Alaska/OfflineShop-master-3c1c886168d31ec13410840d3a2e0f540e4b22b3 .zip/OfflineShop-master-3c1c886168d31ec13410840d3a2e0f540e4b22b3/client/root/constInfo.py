
# OFFLINE_SHOPS
shop_cost=[]
gift_items={}
MyShops=[]
SHOPNAMES_RANGE = 5000