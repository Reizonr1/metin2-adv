##add to end of file
CHR_NAME_RGB_SHOP = (0, 200, 255) ##Shop color