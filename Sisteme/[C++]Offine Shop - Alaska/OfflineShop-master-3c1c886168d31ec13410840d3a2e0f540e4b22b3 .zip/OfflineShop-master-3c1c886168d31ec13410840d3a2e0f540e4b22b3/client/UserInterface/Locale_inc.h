[..]
//ADD NEW define
#define ENABLE_OFFLINE_SHOP
//#define ENABLE_FULL_YANG
[..]
