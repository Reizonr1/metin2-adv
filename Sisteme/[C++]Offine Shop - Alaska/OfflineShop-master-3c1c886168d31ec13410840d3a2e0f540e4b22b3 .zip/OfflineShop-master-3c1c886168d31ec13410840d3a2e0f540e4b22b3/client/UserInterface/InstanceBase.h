//Find NAMECOLOR_WAYPOINT, and add after
#ifdef ENABLE_OFFLINE_SHOP
			NAMECOLOR_SHOP,
#endif